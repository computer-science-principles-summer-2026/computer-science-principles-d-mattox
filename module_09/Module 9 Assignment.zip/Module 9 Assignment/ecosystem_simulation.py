import turtle
import random

class World:
    def __init__(self, mX, mY):
        self.__maxX = mX
        self.__maxY = mY
        self.__thingList = []
        self.__grid = []

        for aRow in range(self.__maxY):
            row = []
            for aCol in range(self.__maxX):
                row.append(None)
            self.__grid.append(row)

        self.__wTurtle = turtle.Turtle()
        self.__wScreen = turtle.Screen()
        self.__wScreen.setworldcoordinates(0, 0, self.__maxX - 1, 
                                           self.__maxY - 1)
        
        # --- ROBUST IMAGE LOADING: Ignores missing files gracefully ---
        for shape in ["Bear.gif", "Fish.gif", "Plant.gif", "Bird.gif"]:
            try:
                self.__wScreen.addshape(shape)
            except turtle.TclError:
                pass  # Silently ignore if the image file is missing
            
        self.__wTurtle.hideturtle()
        
    def draw(self):
        self.__wScreen.tracer(0)
        self.__wTurtle.forward(self.__maxX - 1)
        self.__wTurtle.left(90)
        self.__wTurtle.forward(self.__maxY - 1)
        self.__wTurtle.left(90)
        self.__wTurtle.forward(self.__maxX - 1)
        self.__wTurtle.left(90)
        self.__wTurtle.forward(self.__maxY - 1)
        self.__wTurtle.left(90)
        for i in range(self.__maxY - 1):
            self.__wTurtle.forward(self.__maxX - 1)
            self.__wTurtle.backward(self.__maxX - 1)
            self.__wTurtle.left(90)
            self.__wTurtle.forward(1)
            self.__wTurtle.right(90)
        self.__wTurtle.forward(1)
        self.__wTurtle.right(90)
        for i in range(self.__maxX - 2):
            self.__wTurtle.forward(self.__maxY - 1)
            self.__wTurtle.backward(self.__maxY - 1)
            self.__wTurtle.left(90)
            self.__wTurtle.forward(1)
            self.__wTurtle.right(90)
        self.__wScreen.tracer(1)

    def addThing(self, aThing, x, y):
        aThing.setX(x)
        aThing.setY(y)
        self.__grid[y][x] = aThing       
        aThing.setWorld(self)
        self.__thingList.append(aThing)  
        aThing.appear()

    def delThing(self, aThing):
        aThing.hide()
        self.__grid[aThing.getY()][aThing.getX()] = None
        self.__thingList.remove(aThing)

    def moveThing(self, oldX, oldY, newX, newY):
        self.__grid[newY][newX] = self.__grid[oldY][oldX]
        self.__grid[oldY][oldX] = None

    def getMaxX(self):
        return self.__maxX

    def getMaxY(self):
        return self.__maxY

    def liveALittle(self):
        # Exercise 11.1: Periodically spawn new plants
        if random.random() < 0.05:  
            x = random.randrange(self.__maxX)
            y = random.randrange(self.__maxY)
            if self.emptyLocation(x, y):
                newPlant = Plant()
                self.addThing(newPlant, x, y)

        if self.__thingList != [ ]:
            aThing = random.randrange(len(self.__thingList))
            randomThing = self.__thingList[aThing]
            randomThing.liveALittle()

    def emptyLocation(self, x, y):
        if self.__grid[y][x] == None:
            return True
        else:
            return False

    def lookAtLocation(self, x, y):
        return self.__grid[y][x]

    def freezeWorld(self):
        self.__wScreen.exitonclick()

class Fish:
    def __init__(self):
        self.__turtle = turtle.Turtle()
        self.__turtle.up()
        self.__turtle.hideturtle()
        
        # Fallback to blue circle if Fish.gif is missing
        try:
            self.__turtle.shape("Fish.gif")
        except turtle.TclError:
            self.__turtle.shape("circle")
            self.__turtle.color("blue")

        self.__xPos = 0
        self.__yPos = 0
        self.__world = None
        self.__breedTick = 0
        self.__starveTick = 0

    def setX(self, newX): self.__xPos = newX
    def setY(self, newY): self.__yPos = newY
    def getX(self): return self.__xPos
    def getY(self): return self.__yPos
    def setWorld(self, aWorld): self.__world = aWorld

    def appear(self):
        self.__turtle.goto(self.__xPos, self.__yPos)
        self.__turtle.showturtle()

    def hide(self):
        self.__turtle.hideturtle()

    def move(self, newX, newY):
        self.__world.moveThing(self.__xPos, self.__yPos, newX, newY)
        self.__xPos = newX
        self.__yPos = newY
        self.__turtle.goto(self.__xPos, self.__yPos)

    def liveALittle(self):
        offsetList = [(-1,1), (0,1), (1,1), (-1,0), (1,0), (-1,-1),(0,-1),(1,-1)]
        adjFish = 0  
        for offset in offsetList:
            newX = self.__xPos + offset[0]
            newY = self.__yPos + offset[1]
            if 0 <= newX < self.__world.getMaxX() and 0 <= newY < self.__world.getMaxY():
                if (not self.__world.emptyLocation(newX, newY)) and \
                    isinstance(self.__world.lookAtLocation(newX, newY), Fish):
                    adjFish = adjFish + 1

        if adjFish >= 2:   
            self.__world.delThing(self)
        else:
            self.__breedTick = self.__breedTick + 1
            if self.__breedTick >= 12:  
                self.tryToBreed()
            self.tryToEat()
            if self.__starveTick >= 15:  
                self.__world.delThing(self)
            else:
                self.tryToMove()

    def tryToBreed(self):
        offsetList = [(-1,1), (0,1), (1,1), (-1,0), (1,0), (-1,-1),(0,-1),(1,-1)]
        randomOffsetIndex = random.randrange(len(offsetList))
        randomOffset = offsetList[randomOffsetIndex]
        nextX = self.__xPos + randomOffset[0]
        nextY = self.__yPos + randomOffset[1]
        while not (0 <= nextX < self.__world.getMaxX() and 0 <= nextY < self.__world.getMaxY() ):
            randomOffsetIndex = random.randrange(len(offsetList))
            randomOffset = offsetList[randomOffsetIndex]
            nextX = self.__xPos + randomOffset[0]
            nextY = self.__yPos + randomOffset[1]
        if self.__world.emptyLocation(nextX, nextY):
            childThing = Fish()
            self.__world.addThing(childThing, nextX, nextY)
            self.__breedTick = 0     

    def tryToMove(self):
        offsetList = [(-1,1), (0,1), (1,1), (-1,0), (1,0), (-1,-1),(0,-1),(1,-1)]
        randomOffsetIndex = random.randrange(len(offsetList))
        randomOffset = offsetList[randomOffsetIndex]
        nextX = self.__xPos + randomOffset[0]
        nextY = self.__yPos + randomOffset[1]
        while not(0 <= nextX < self.__world.getMaxX() and 0 <= nextY < self.__world.getMaxY() ):
            randomOffsetIndex = random.randrange(len(offsetList))
            randomOffset = offsetList[randomOffsetIndex]
            nextX = self.__xPos + randomOffset[0]
            nextY = self.__yPos + randomOffset[1]
        if self.__world.emptyLocation(nextX, nextY):
            self.move(nextX, nextY)
           
    def tryToEat(self):
        offsetList = [(-1,1), (0,1) ,(1,1), (-1,0), (1,0), (-1,-1),(0,-1),(1,-1)]
        adjPrey = []     
        for offset in offsetList:
            newX = self.__xPos + offset[0]
            newY = self.__yPos + offset[1]
            if 0 <= newX < self.__world.getMaxX() and 0 <= newY < self.__world.getMaxY():
                if (not self.__world.emptyLocation(newX, newY)) and  \
                       isinstance(self.__world.lookAtLocation(newX, newY), Plant):
                    adjPrey.append(self.__world.lookAtLocation(newX, newY))
        if len(adjPrey) > 0:  
            randomPrey = adjPrey[random.randrange(len(adjPrey))]
            preyX = randomPrey.getX()
            preyY = randomPrey.getY()
            self.__world.delThing(randomPrey)  
            self.move(preyX, preyY)            
            self.__starveTick = 0
        else:
            self.__starveTick = self.__starveTick + 1


class Bear:
    def __init__(self):
        self.__turtle = turtle.Turtle()
        self.__turtle.up()
        self.__turtle.hideturtle()
        
        # Fallback to brown square if Bear.gif is missing
        try:
            self.__turtle.shape("Bear.gif")
        except turtle.TclError:
            self.__turtle.shape("square")
            self.__turtle.color("brown")

        self.__xPos = 0
        self.__yPos = 0
        self.__world = None
        self.__starveTick = 0
        self.__breedTick = 0

    def setX(self, newX): self.__xPos = newX
    def setY(self, newY): self.__yPos = newY
    def getX(self): return self.__xPos
    def getY(self): return self.__yPos
    def setWorld(self, aWorld): self.__world = aWorld

    def appear(self):
        self.__turtle.goto(self.__xPos, self.__yPos)
        self.__turtle.showturtle()

    def hide(self):
        self.__turtle.hideturtle()

    def move(self, newX, newY):
        self.__world.moveThing(self.__xPos, self.__yPos, newX, newY)
        self.__xPos = newX
        self.__yPos = newY
        self.__turtle.goto(self.__xPos, self.__yPos)

    def tryToBreed(self):
        offsetList = [(-1,1), (0,1), (1,1), (-1,0), (1,0), (-1,-1),(0,-1),(1,-1)]
        randomOffsetIndex = random.randrange(len(offsetList))
        randomOffset = offsetList[randomOffsetIndex]
        nextX = self.__xPos + randomOffset[0]
        nextY = self.__yPos + randomOffset[1]
        while not (0 <= nextX < self.__world.getMaxX() and 0 <= nextY < self.__world.getMaxY() ):
            randomOffsetIndex = random.randrange(len(offsetList))
            randomOffset = offsetList[randomOffsetIndex]
            nextX = self.__xPos + randomOffset[0]
            nextY = self.__yPos + randomOffset[1]
        if self.__world.emptyLocation(nextX, nextY):
            childThing = Bear()
            self.__world.addThing(childThing, nextX, nextY)
            self.__breedTick = 0     

    def tryToMove(self):
        offsetList = [(-1,1), (0,1), (1,1), (-1,0), (1,0), (-1,-1),(0,-1),(1,-1)]
        randomOffsetIndex = random.randrange(len(offsetList))
        randomOffset = offsetList[randomOffsetIndex]
        nextX = self.__xPos + randomOffset[0]
        nextY = self.__yPos + randomOffset[1]
        while not(0 <= nextX < self.__world.getMaxX() and 0 <= nextY < self.__world.getMaxY() ):
            randomOffsetIndex = random.randrange(len(offsetList))
            randomOffset = offsetList[randomOffsetIndex]
            nextX = self.__xPos + randomOffset[0]
            nextY = self.__yPos + randomOffset[1]
        if self.__world.emptyLocation(nextX, nextY):
            self.move(nextX, nextY)

    def liveALittle(self):
        self.__breedTick = self.__breedTick + 1
        if self.__breedTick >= 8:  
            self.tryToBreed()
        self.tryToEat()
        if self.__starveTick >= 15:  
            self.__world.delThing(self)
        else:
            self.tryToMove()

    def tryToEat(self):
        offsetList = [(-1,1), (0,1) ,(1,1), (-1,0), (1,0), (-1,-1),(0,-1),(1,-1)]
        adjPrey = []     
        for offset in offsetList:
            newX = self.__xPos + offset[0]
            newY = self.__yPos + offset[1]
            if 0 <= newX < self.__world.getMaxX() and 0 <= newY < self.__world.getMaxY():
                if (not self.__world.emptyLocation(newX, newY)) and  \
                        isinstance(self.__world.lookAtLocation(newX, newY), Fish):
                    adjPrey.append(self.__world.lookAtLocation(newX, newY))
        if len(adjPrey) > 0:  
            randomPrey = adjPrey[random.randrange(len(adjPrey))]
            preyX = randomPrey.getX()
            preyY = randomPrey.getY()
            self.__world.delThing(randomPrey)  
            self.move(preyX, preyY)            
            self.__starveTick = 0
        else:
            self.__starveTick = self.__starveTick + 1


class Bird:
    def __init__(self):
        self.__turtle = turtle.Turtle()
        self.__turtle.up()
        self.__turtle.hideturtle()
        
        # Fallback to red turtle shape if Bird.gif is missing
        try:
            self.__turtle.shape("Bird.gif")
        except turtle.TclError:
            self.__turtle.shape("turtle")
            self.__turtle.color("red")

        self.__xPos = 0
        self.__yPos = 0
        self.__world = None
        self.__starveTick = 0
        self.__breedTick = 0

    def setX(self, newX): self.__xPos = newX
    def setY(self, newY): self.__yPos = newY
    def getX(self): return self.__xPos
    def getY(self): return self.__yPos
    def setWorld(self, aWorld): self.__world = aWorld

    def appear(self):
        self.__turtle.goto(self.__xPos, self.__yPos)
        self.__turtle.showturtle()

    def hide(self):
        self.__turtle.hideturtle()

    def move(self, newX, newY):
        self.__world.moveThing(self.__xPos, self.__yPos, newX, newY)
        self.__xPos = newX
        self.__yPos = newY
        self.__turtle.goto(self.__xPos, self.__yPos)

    def tryToBreed(self):
        offsetList = [(-1,1), (0,1), (1,1), (-1,0), (1,0), (-1,-1),(0,-1),(1,-1)]
        randomOffsetIndex = random.randrange(len(offsetList))
        randomOffset = offsetList[randomOffsetIndex]
        nextX = self.__xPos + randomOffset[0]
        nextY = self.__yPos + randomOffset[1]
        while not (0 <= nextX < self.__world.getMaxX() and 0 <= nextY < self.__world.getMaxY() ):
            randomOffsetIndex = random.randrange(len(offsetList))
            randomOffset = offsetList[randomOffsetIndex]
            nextX = self.__xPos + randomOffset[0]
            nextY = self.__yPos + randomOffset[1]
        if self.__world.emptyLocation(nextX, nextY):
            childThing = Bird()
            self.__world.addThing(childThing, nextX, nextY)
            self.__breedTick = 0     

    def tryToMove(self):
        offsetList = [(-1,1), (0,1), (1,1), (-1,0), (1,0), (-1,-1),(0,-1),(1,-1)]
        randomOffsetIndex = random.randrange(len(offsetList))
        randomOffset = offsetList[randomOffsetIndex]
        nextX = self.__xPos + randomOffset[0]
        nextY = self.__yPos + randomOffset[1]
        while not(0 <= nextX < self.__world.getMaxX() and 0 <= nextY < self.__world.getMaxY() ):
            randomOffsetIndex = random.randrange(len(offsetList))
            randomOffset = offsetList[randomOffsetIndex]
            nextX = self.__xPos + randomOffset[0]
            nextY = self.__yPos + randomOffset[1]
        if self.__world.emptyLocation(nextX, nextY):
            self.move(nextX, nextY)

    def liveALittle(self):
        self.__breedTick = self.__breedTick + 1
        if self.__breedTick >= 10:  
            self.tryToBreed()
        self.tryToEat()
        if self.__starveTick >= 12:  
            self.__world.delThing(self)
        else:
            self.tryToMove()

    def tryToEat(self):
        offsetList = [(-1,1), (0,1) ,(1,1), (-1,0), (1,0), (-1,-1),(0,-1),(1,-1)]
        adjPrey = []     
        for offset in offsetList:
            newX = self.__xPos + offset[0]
            newY = self.__yPos + offset[1]
            if 0 <= newX < self.__world.getMaxX() and 0 <= newY < self.__world.getMaxY():
                if (not self.__world.emptyLocation(newX, newY)) and  \
                        isinstance(self.__world.lookAtLocation(newX, newY), Fish):
                    adjPrey.append(self.__world.lookAtLocation(newX, newY))
        if len(adjPrey) > 0:  
            randomPrey = adjPrey[random.randrange(len(adjPrey))]
            preyX = randomPrey.getX()
            preyY = randomPrey.getY()
            self.__world.delThing(randomPrey)  
            self.move(preyX, preyY)            
            self.__starveTick = 0
        else:
            self.__starveTick = self.__starveTick + 1


class Plant:
    def __init__(self):
        self.__turtle = turtle.Turtle()
        self.__turtle.up()
        self.__turtle.hideturtle()
        
        # Fallback to green triangle if Plant.gif is missing
        try:
            self.__turtle.shape("Plant.gif")
        except turtle.TclError:
            self.__turtle.shape("triangle")
            self.__turtle.color("green")

        self.__xPos = 0
        self.__yPos = 0
        self.__world = None
        self.__breedTick = 0

    def setX(self, newX): self.__xPos = newX
    def setY(self, newY): self.__yPos = newY
    def getX(self): return self.__xPos
    def getY(self): return self.__yPos
    def setWorld(self, aWorld): self.__world = aWorld

    def appear(self):
        self.__turtle.goto(self.__xPos, self.__yPos)
        self.__turtle.showturtle()

    def hide(self):
        self.__turtle.hideturtle()

    def tryToBreed(self):
        offsetList = [(-1,1), (0,1), (1,1), (-1,0), (1,0), (-1,-1),(0,-1),(1,-1)]
        randomOffsetIndex = random.randrange(len(offsetList))
        randomOffset = offsetList[randomOffsetIndex]
        nextX = self.__xPos + randomOffset[0]
        nextY = self.__yPos + randomOffset[1]
        while not (0 <= nextX < self.__world.getMaxX() and 0 <= nextY < self.__world.getMaxY() ):
            randomOffsetIndex = random.randrange(len(offsetList))
            randomOffset = offsetList[randomOffsetIndex]
            nextX = self.__xPos + randomOffset[0]
            nextY = self.__yPos + randomOffset[1]
        if self.__world.emptyLocation(nextX, nextY):
            childThing = Plant()
            self.__world.addThing(childThing, nextX, nextY)
            self.__breedTick = 0     

    def liveALittle(self):
        self.__breedTick = self.__breedTick + 1
        if self.__breedTick >= 3:  
            self.tryToBreed()


def mainSimulation():
    numberOfBears = 10
    numberOfFish = 10
    numberOfPlants = 10
    numberOfBirds = 5  
    worldLifeTime = 2500
    worldWidth = 50
    worldHeight = 25
 
    myWorld = World(worldWidth, worldHeight)
    myWorld.draw()

    for i in range(numberOfFish):
        newFish = Fish()
        x = random.randrange(myWorld.getMaxX())
        y = random.randrange(myWorld.getMaxY())
        while not myWorld.emptyLocation(x, y):
            x = random.randrange(myWorld.getMaxX())
            y = random.randrange(myWorld.getMaxY())
        myWorld.addThing(newFish, x, y)

    for i in range(numberOfBears):
        newBear = Bear()
        x = random.randrange(myWorld.getMaxX())
        y = random.randrange(myWorld.getMaxY())
        while not myWorld.emptyLocation(x, y):
            x = random.randrange(myWorld.getMaxX())
            y = random.randrange(myWorld.getMaxY())
        myWorld.addThing(newBear, x, y)
        
    for i in range(numberOfPlants):
        newPlant = Plant()
        x = random.randrange(myWorld.getMaxX())
        y = random.randrange(myWorld.getMaxY())
        while not myWorld.emptyLocation(x, y):
            x = random.randrange(myWorld.getMaxX())
            y = random.randrange(myWorld.getMaxY())
        myWorld.addThing(newPlant, x, y)

    for i in range(numberOfBirds):
        newBird = Bird()
        x = random.randrange(myWorld.getMaxX())
        y = random.randrange(myWorld.getMaxY())
        while not myWorld.emptyLocation(x, y):
            x = random.randrange(myWorld.getMaxX())
            y = random.randrange(myWorld.getMaxY())
        myWorld.addThing(newBird, x, y)

    for i in range(worldLifeTime):
        myWorld.liveALittle()

    myWorld.freezeWorld()

if __name__ == "__main__":
    mainSimulation()